import React from 'react'
import { Link } from "react-router-dom";
const PostPage = () => {
  return (
    <div>
        <ol>
            <li ><Link>Post 1</Link></li>
            <li ><Link>Post 2</Link></li>
            <li ><Link>Post 3</Link></li>
        </ol>
    </div>
  )
}

export default PostPage